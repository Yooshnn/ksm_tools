$(".filtertoggle").click(function() {
    var type = $(this).attr('id');
    type = type.substring(6);
    target = "input[name=" + type + "]"
    var input = $(target + ":checked").map(function(_, el) {
        return 1;
    }).get();
    console.log(input.length)
    if (input.length > 0) {
        $(target).each(function() { 
            this.checked = false; 
        });
    }
    else {
        $(target).each(function() { 
            this.checked = true; 
        });
    }
});
