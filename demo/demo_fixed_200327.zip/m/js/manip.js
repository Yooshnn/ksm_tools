var firsttr = 0;
var beg = 0;
var end = 50;
var lasttr = Number($('.lasttr').attr('id'))-1;

option1 = ".pages"
option2 = ".pages"
option3 = ".pages"
option4 = ".pages"

nextlock = false;
prevlock = true;

loadPage();

function loadPage() {
    $('.pages').each(function(i, obj) {
        $(this).hide();
        if ((i >= beg) && (i <= end)) {
            if (isDisplayable(this)) {
                $(this).show();
            }
        }
    });
}
function isDisplayable(e){
    return ($(e).is(option1) == true) && ($(e).is(option2) == true) && ($(e).is(option3) == true) && ($(e).is(option4) == true);
}
function resetbegend(){ // 처음 볼수있는 위치로 beg
    nextlock = true;
    prevlock = true;

    begisset = false;
    $('.pages').each(function(i, obj) {
        if ((isDisplayable(this)) && (!begisset)) {
            beg = i;
            begisset = true;
            firsttr = i;
        }
    });
    count = 0;
    $('.pages').each(function(i, obj) {
        if (i >= firsttr) {
            if ((count < 51) && isDisplayable(obj)) {
                count += 1;
                end = i;
            }
            if ((count == 51) || (i >= $('.pages').length)) {
                nextlock = false;
                count = 10000;
            }
            if (isDisplayable(obj)){
                lasttr = i;
            }
        }
    });
    console.log(firsttr + "_" + lasttr)
}


$("#nextpage").click(function() {if (!nextlock) {
    prevlock = false;
    nextlock = true;
    beg_ = beg;
    end_ = end;

    beg = 0;
    count = 0;

    $('.pages').each(function(i, obj) {
        if (i >= end) {
            if ((count < 50) && isDisplayable(obj)) {
                if (beg == 0) beg = i;
                count += 1;
                end = i + 1;
                console.log(end)
            }
            else if (count == 50 && isDisplayable(obj)){
                nextlock = false;
            }
        }
    })
    console.log(nextlock);
    loadPage();
}});
$("#prevpage").click(function() { if (!prevlock) {
    nextlock = false;
    prevlock = true;
    beg_ = beg;
    end_ = end;

    end = $('.pages').length;
    count = 0;
    
    $($('.pages').get().reverse()).each(function(i, obj) {
        if (i >= $('.pages').length - beg_) {
            if ((count < 50) && isDisplayable(obj)) {
                if (end == $('.pages').length) end = $('.pages').length - i;
                count += 1;
                beg = $('.pages').length - i - 1;
                console.log(beg)
            }
            else if (count == 50 && isDisplayable(obj)) {
                prevlock = false;
            }
        }
    })
    console.log(prevlock);
    loadPage();
}});

$("#filterall").click(function() {
    $('input').each(function() { 
        this.checked = true; 
    });
});
$("#filternone").click(function() {
    $('input').each(function() { 
        this.checked = false; 
    });
});

$("#filtersubmit").click(function() {
    $(".pages").hide();
    option1 = ".default"
    option2 = ".default"
    option3 = ".default"
    option4 = ".default"

    var userinput1 = $("input[name=level]:checked").map(function(_, el) {
        return $(el).val();
    }).get();
    $.each(userinput1, function( index, value ) {
        option1 += ",." + value
    });
    var userinput2 = $("input[name=difficulty]:checked").map(function(_, el) {
        return $(el).val();
    }).get();
    $.each(userinput2, function( index, value ) {
        option2 += ",." + value
    });
    var userinput3 = $("input[name=rate]:checked").map(function(_, el) {
        return $(el).val();
    }).get();
    $.each(userinput3, function( index, value ) {
        option3 += ",." + value
    });
    var userinput4 = $("input[name=grade]:checked").map(function(_, el) {
        return $(el).val();
    }).get();
    $.each(userinput4, function( index, value ) {
        option4 += ",." + value
    });

    beg = -1;
    end = 0;
    count = 0;
    $('.pages').each(function(i, obj) {
        if (i >= end) {
            if ((count < 51) && isDisplayable(obj)) {
                if (beg == -1) {
                    beg = i;
                }
                count += 1;
            }
            if (((count == 51) || (i >= $('.pages').length)) && (end <= beg)) {
                end = i;
            }
        }
    });
    resetbegend();
    loadPage();
});