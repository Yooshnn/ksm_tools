var lang = {
    "kr": {
        "0": "환영합니다!",
        "1": "플레이 정보를 확인하세요.",
        "2": "내 플레이 기록 열람",
        "3": "개발자 정보"
    },
    "en": {
        "0": "Welcome!"
    }
}

$(document).ready(function() {
    var c = "kr";
    $(".l").each(function(index, element) {
      $(this).text(lang[c][$(this).attr("key")]);
    });
});